public interface Asesoria {
    void analizarUsuario();
}